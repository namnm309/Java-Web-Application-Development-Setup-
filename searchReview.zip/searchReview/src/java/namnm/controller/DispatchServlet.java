/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package namnm.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ngoc Lan
 */
@WebServlet(name = "DispatchServlet", urlPatterns = {"/DispatchServlet"})//annotation 
public class DispatchServlet extends HttpServlet {
    private final String LOGIN_PAGE="login.html";//5.1
    private final String LOGIN_CONTROLLER="LoginServlet" ;//6.5 ,copy bên trong web.xml
    private final String SEARCH_LAST_NAME="SearchLastNameServlet";//9.2 => 9.3 tạo servlet chức năng 
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url=LOGIN_PAGE;//5.2
        
        
        
        //1-User nhấn gì ? 
        String button=request.getParameter("btAction");
        /*2-Request => Server => Contrainer => Controller => từ nay mọi thứ phải thông qua DispatchServlet (điều phối) , copy urlPattern
        bỏ / paste sang welcome-file trong web.xml
        */
        
        //3-Sau khi truy cập vào Dispatchservlet thông qua web.xml gặp dòng 37
        //4-Sau khi gặp dòng 37 thì tiếp theo giá trị button = null vì ko truyền parameter nào hết 
        
        //Trong mvc khi thêm 1 chức năng mới 
               /*
               -Bước 1 : tạo giao diện (view ) => 5 , 9 
               -Bước 2 : mapping chức năng mới vào điều phối (DispatchServlet) => 6
               -Bước 3 : tạo servlet chức năng => 7
               */
               
               /*6.Nhảy qua login.html để thay đổi action vì mọi thứ đều phải thông qua điều phối 
               là DispatchServlet thay vì truy cập thẳng vào servlet chức năng 
               */
        
        
        try  {
            //5-vì button bằng null => chuyển sang trang login => quy tắc 3 
           if (button == null){   
               //Khai báo 
               //Đóng 
               //Viết code 
               
               
               
           //6.3) else if , mapping chức năng mới , thông báo cho điều phối có tính năng mới     
           } else if (button.equals("Login")){//6.4) Copy từ bên login.html
               url=LOGIN_CONTROLLER;//6.6 map url pattern 
           } else if (button.equals("Search")) {//9.1 
               url=SEARCH_LAST_NAME;
           }
        } finally {
            RequestDispatcher rd=request.getRequestDispatcher(url);//5.3
            rd.forward(request, response);//5.4
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

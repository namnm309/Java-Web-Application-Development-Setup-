/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package namnm.registration;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import namnm.utils.DBHelper;

/**
 *
 * @author Ngoc Lan
 */
public class RegistrationDAO implements Serializable {

    public boolean checkLogin(String username, String password)
            throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;

        try {
            //1.Connect DB 
            con = DBHelper.makeConnection();
            //2.Create SQL Strings
            String sql = "Select username "
                    + "FROM AccountTable "
                    + "WHERE username = ? "
                    + "AND password = ?";
            //3.Crate SQL Statement 
            stm = con.prepareStatement(sql);
            stm.setString(1, username);
            stm.setString(2, password);

            //4.Excute query 
            rs = stm.executeQuery();
            //5.Process 
            if (rs.next()) {
                return true;
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                stm.close();
            }

            if (con != null) {
                con.close();
            }
        }
        return false;
    }

    /*10 Search trả về nhiều record 
  -Mỗi record map trên bộ nhớ là 1 DTO 
  => DTO là javaclass,thuộc pakage là tên bảng => tạo DTO 10.1  
     */
//10.2 chứa nhiều hơn 1 DTO => list 
    private List<RegistrationDTO> account;

//10.3 Ở DAO muốn public ra bên ngoài phải ko phải do set vào mà map lên 
    public List<RegistrationDTO> getAccount() { // get + Ctrl + space 
        return account;
    }

//10.4 Viết hàm search 
    public void searchLastname(String searchValue)
            throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        boolean result=false;
        
        try {
            //1.Connect DB 
            con = DBHelper.makeConnection();
            if (con != null) {
            //2.Create SQL Strings
                //10.5
            String sql = "Select username, password, lastname,isAdmin "
                    + "FROM Users2 "
                    + "Where lastname like ?"; 
            //3.Crate SQL Statement 
            stm = con.prepareStatement(sql);
                //10.6
            stm.setString(1,"%" + searchValue + "%" );//Kí tự đại diện cho ko kí tự hay bao nhiêu kí tự cũng đc là %
            //4.Excute query 
            rs = stm.executeQuery();
            //5.Process 
                //10.7 lện truy vấn trả ra nhiều dòng => dùng while 
            while(rs.next()){
                String username=rs.getString("username");//varchar => String , column 
                String password=rs.getString("password");
                String fullName=rs.getString("lastname");
                boolean role =rs.getBoolean("isAdmin");
                
                //10.8 map vào DTO
                RegistrationDTO dto=new RegistrationDTO(username, password, fullName, role);
            
                
                /*10.9 kiểm tra có null hay ko , đối với nhưng object do mình viết 
                thì nên check nó có null còn nhữn object do container thì nắm life cycle là đc 
                */              
                if(this.account == null) {
                    this.account = new ArrayList<>();
                    }//end account are not existed 
                    this.account.add(dto);
                    //10.10 đang ở DAO => 11 Servlet chức năng 
            }           
            }//end traverse Result Set
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                stm.close();
            }

            if (con != null) {
                con.close();
            }
        }
    }

}


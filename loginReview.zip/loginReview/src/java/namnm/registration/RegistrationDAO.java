/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package namnm.registration;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import namnm.utils.DBHelper;

/**
 *
 * @author Ngoc Lan
 */
public class RegistrationDAO implements Serializable {
    /*
    Quy tắc đặt tên DAO 
    -Class Name : tên chữ cái thường đầu tiên  viết hoa + DAO 
    VD: RegistrationDAO
    -Package : tên user (viết thường).tên class(viết thường) 
    VD: namnm.registration
    */
    
    //2b) implement serializable ( vì đang ở phía sever nên giao tiếp thông qua byte or bit stream ) 
    
    //2c) DAO có nhiệm vụ tạo phương thức để access và lấy data từ DB => tạo phương thức 
    //=> tạo phương thức checkLogin để check username và password 
    
    
    public boolean checkLogin (String username,String password ) 
                    throws SQLException, ClassNotFoundException{
        //3b) Khởi tạo đối tượng cho bước 1 là connect DB 
        Connection con=null;
        PreparedStatement stm=null;
        ResultSet rs=null;
        
        
        
        //3c) trong mọi trường hợp đóng nó lại và trong mọi trường hợp phải kiểm tra xem nó có khác null hay không =>try finally
        try {
        
        
        
        //Để thực hiện kết nối và xử lí database có những bước như sau 
        //1.Connect DB
            //4 connect 
        con=DBHelper.makeConnection();//ClassNotFoundException
            //4a) Kiểm tra có khác null trong mọi th
        if (con !=null) {
            //4b làm bc 2 , 3 ,4 ,5 
        //2.Create SQL String
            String sql = "Select username "
                    +"FROM AccountTable "                   //Lưu ý dấu space nếu ko sẽ bị lỗi truy vấn và nó sẽ ko thông báo lỗi 
                    +"WHERE username = ? "
                    +"AND password = ?"; 
        //3.Create SQL Statement 
            //Khai báo trước => stm
            //Đóng =>stm !=null 
            //Viết code 
        stm=con.prepareStatement(sql);
        stm.setString(1, username);//từ trên xuống , trái -> phải => 1
        stm.setString(2, password);
        //4.Excute Query 
            //Khai báo 
            //Đóng 
            //Viết code
        rs=stm.executeQuery();
        //5.Process ( xử lí ) , đối với insert và update thì là kết quả 
        if (rs.next()){
            return true;
            //4c) đang ở DAO => Controller = LoginServlet
        }
            //3) từ DAO đến Database => Database dùng chung => Tạo DBHelper or DBUtils hỗ trợ sp cho các method dùng chung cho toàn app (javaclass)
    
        } //process when connection is existed 
        }finally {
            if(rs !=null) {
                rs.close();
            }
            if(stm !=null) {
                stm.close();//khai báo chiều thuận , đóng chiều ngược 
            }
            if (con != null) {
                con.close();//lện này dùng SQLException để fix 
            }
        }
    
      
    
    
    return false;
}
}

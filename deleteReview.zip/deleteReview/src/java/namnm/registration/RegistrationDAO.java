/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package namnm.registration;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import namnm.utils.DBHelper;

/**
 *
 * @author Ngoc Lan
 */
public class RegistrationDAO implements Serializable {

    public boolean checkLogin(String username, String password)
            throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;

        try {
            //1.Connect DB 
            con = DBHelper.makeConnection();
            //2.Create SQL Strings
            String sql = "Select username "
                    + "FROM AccountTable "
                    + "WHERE username = ? "
                    + "AND password = ?";
            //3.Crate SQL Statement 
            stm = con.prepareStatement(sql);
            stm.setString(1, username);
            stm.setString(2, password);

            //4.Excute query 
            rs = stm.executeQuery();
            //5.Process 
            if (rs.next()) {
                return true;
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                stm.close();
            }

            if (con != null) {
                con.close();
            }
        }
        return false;
    }

    private List<RegistrationDTO> account;

    public List<RegistrationDTO> getAccount() { // get + Ctrl + space 
        return account;
    }

    public void searchLastname(String searchValue)
            throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        boolean result = false;

        try {
            //1.Connect DB 
            con = DBHelper.makeConnection();
            if (con != null) {
                //2.Create SQL Strings
                //10.5
                String sql = "Select username, password, lastname,isAdmin "
                        + "FROM Users2 "
                        + "Where lastname like ?";
                //3.Crate SQL Statement 
                stm = con.prepareStatement(sql);

                stm.setString(1, "%" + searchValue + "%");//Kí tự đại diện cho ko kí tự hay bao nhiêu kí tự cũng đc là %
                //4.Excute query 
                rs = stm.executeQuery();
                //5.Process 

                while (rs.next()) {
                    String username = rs.getString("username");//varchar => String , column 
                    String password = rs.getString("password");
                    String fullName = rs.getString("lastname");
                    boolean role = rs.getBoolean("isAdmin");

                    RegistrationDTO dto = new RegistrationDTO(username, password, fullName, role);

                    if (this.account == null) {
                        this.account = new ArrayList<>();
                    }//end account are not existed 
                    this.account.add(dto);

                }
            }//end traverse Result Set
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                stm.close();
            }

            if (con != null) {
                con.close();
            }
        }
    }

    public boolean deleteAccount(String username)
                        throws SQLException,ClassNotFoundException {
        Connection con = null;
        PreparedStatement stm = null;
        boolean result = false;
        try {
            // 1. Kết nối tới cơ sở dữ liệu
            con = DBHelper.makeConnection();

            if (con != null) {
                // 2. Tạo câu lệnh SQL DELETE chỉ xóa dữ liệu từ bảng Registration dựa trên username
                String sql = "DELETE FROM Users2 WHERE username = ?";

                // 3. Tạo PreparedStatement và thiết lập tham số username
                stm = con.prepareStatement(sql);
                stm.setString(1, username); // Thiết lập tham số username

                // 4. Thực thi câu lệnh SQL DELETE
                int affectedRows = stm.executeUpdate();

                // 5. Xử lý kết quả của việc xóa
                if (affectedRows > 0) {
                    result = true; // Nếu có hàng bị xóa, trả về true
                }
            }
        } finally {
            // 6. Đóng các tài nguyên (PreparedStatement và Connection) sau khi sử dụng
            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return result; // Trả về kết quả xóa (true/false)

    }

}

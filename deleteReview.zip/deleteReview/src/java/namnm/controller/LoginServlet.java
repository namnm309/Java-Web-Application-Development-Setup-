/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package namnm.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import namnm.registration.RegistrationDAO;

/**
 *
 * @author Ngoc Lan
 */
public class LoginServlet extends HttpServlet {

    private final String INVALIE_PAGE = "invalid.html";
    private final String SEARCH_PAGE = "search.html";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        //PrintWriter out = response.getWriter();   khi mỗi servlet chức năng làm 1 chức năng duy nhất bỏ đi cùng với out.close ở finally , 
        String url = INVALIE_PAGE;
        String username = request.getParameter("txtUsername");
        String password = request.getParameter("txtPassword");
        String button = request.getParameter("btAction");

        //Tip số lượng parameter chức năng = số lượng parameter trên web - 1 ( 1 là button ) 
        try {
            //if (button.equals("Login")) {//7 Với chức năng search , đã có điều phối , ko cần check có phải là login ko => bỏ 
            //Ở bước 7 hiện tại sau khi login ra hai trang thì sẽ hiển thị đường truyều url chỉ ra hai trang đó 
            //vd:http://localhost:8084/LoginReview2/invalid.html khi sai 
            //vd:http://localhost:8084/LoginReview2/search.html khi đúng 
            //Làm sao để ẩn đi chỉ hiển thị DispacthServlet 
            //=> bước 8 
            
            //*   
                //-với chức năng search , đem 2 tg này ra ngoài 
//                String username=request.getParameter("txtUsername");
//                String password=request.getParameter("txtPassword");
             //*/
            RegistrationDAO dao = new RegistrationDAO();
            boolean result = dao.checkLogin(username, password);

            if (result) {
                url = SEARCH_PAGE;
            }
            //}

        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
//8            response.sendRedirect(url);
            RequestDispatcher rd=request.getRequestDispatcher(url);//đã fix lỗi chỉ ra url của trang đó khi xử lí 
            rd.forward(request, response);
            //out.close();   
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

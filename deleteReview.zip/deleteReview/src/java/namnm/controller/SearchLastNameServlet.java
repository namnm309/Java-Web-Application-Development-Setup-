/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package namnm.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import namnm.registration.RegistrationDAO;
import namnm.registration.RegistrationDTO;

/**
 *
 * @author Ngoc Lan
 */
@WebServlet(name = "SearchLastNameServlet", urlPatterns = {"/SearchLastNameServlet"})
public class SearchLastNameServlet extends HttpServlet {
    private final String SEARCH_PAGE="search.html";//9.8 => 10 DAO 
    private final String SEARCH_RESULT_PAGE="search.jsp";//11.5
    
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        //9.3 form search đang truyền vào server 2 parameter là txtSearchVlue và Search Button 
        //9.4 =>Lấy txtSearchValue
        String searchValue=request.getParameter("txtSearchValue");
        String url= SEARCH_PAGE;//11.8
        
        
        try {
        //9.5 khi chuỗi ko rỗng thì search , khi có giá trị trong ô search 
        //9.6 => check chuỗi value khác rỗng hay null => rỗng 
        //9.7 Vì đang ở sever thì parameter đã tồn tại => ko thể null ( vì đã tồn tại và chưa có giá trị thì rỗng ) 
        //9.7 Lưu ý thêm nhớ tránh nút space => trim()
        if (searchValue.trim().length()>0) {//9.7 
            //khi user ko nhập gì cả thì trở về search page => return search.html 9.8
            
            //11 call DAO 
            RegistrationDAO dao=new RegistrationDAO();
            dao.searchLastname(searchValue);
            //11.3 lấy kêt quả search 
            List<RegistrationDTO> result=dao.getAccount();
            //11.4 html là tĩnh => chuyển sang trang trình bày dữ liệu động => 11.5
            
            //11.6
            request.setAttribute("SEARCHRESULT", result);
            //11.9
            url=SEARCH_RESULT_PAGE;
        } //end if searchValue has value
        } catch (ClassNotFoundException ex){//11.1
            ex.printStackTrace();
        } catch (SQLException ex) {//11.2
            ex.printStackTrace();
        } finally {
            //11.7 
            //Để chuyển từ controller sang trang search mà vẫn giữ nguyên giá trị của search result
            //Dùng forward thay sendDirect vì sendDirect thì request obj bị hủy 
            RequestDispatcher rd=request.getRequestDispatcher(url);
            rd.forward(request, response);//=> search jsp final step  
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
